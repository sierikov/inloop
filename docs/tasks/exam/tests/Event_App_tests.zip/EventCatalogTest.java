import org.junit.Test;

import static org.junit.Assert.*;

public class EventCatalogTest {
    @Test
    public void testInterface() {
        assertTrue(EventCatalog.class.isInterface());
    }
}