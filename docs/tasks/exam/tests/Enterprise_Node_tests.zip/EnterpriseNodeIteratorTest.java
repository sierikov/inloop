import org.junit.Test;

import static org.junit.Assert.*;

public class EnterpriseNodeIteratorTest {
    @Test
    public void testInterface() {
        assertTrue(EnterpriseNodeIterator.class.isInterface());
    }
}