import org.junit.Test;

import static org.junit.Assert.*;

public class EnterpriseNodeTest {
    @Test
    public void testInterface() {
        assertTrue(EnterpriseNode.class.isInterface());
    }
}