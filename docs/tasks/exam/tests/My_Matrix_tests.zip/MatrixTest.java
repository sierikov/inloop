import org.junit.Test;

import static org.junit.Assert.*;

public class MatrixTest {
    @Test
    public void testInterface() {
        assertTrue(Matrix.class.isInterface());
    }
}