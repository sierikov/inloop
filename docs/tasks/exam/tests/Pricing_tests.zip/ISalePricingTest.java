import org.junit.Test;

import static org.junit.Assert.*;

public class ISalePricingTest {
    @Test
    public void testInterface() {
        assertTrue(ISalePricing.class.isInterface());
    }
}