import org.junit.Test;

import static org.junit.Assert.*;

public class PayrollDispositionTest {
    @Test
    public void testInterface() {
        assertTrue(PayrollDisposition.class.isInterface());
    }
}