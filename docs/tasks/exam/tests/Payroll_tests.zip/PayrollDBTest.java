import org.junit.Test;

import static org.junit.Assert.*;

public class PayrollDBTest {
    @Test
    public void testInterface() {
        assertTrue(PayrollDB.class.isInterface());
    }
}